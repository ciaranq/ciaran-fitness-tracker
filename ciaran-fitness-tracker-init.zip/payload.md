
cat << 'EOF' > make_init_zip.py
import zipfile
from pathlib import Path

files = {
    # 1. Agentic Governance & Specifications
    "AGENTS.md": """# AGENTS.md: Multi-Agent Operating Contract & Tool Permissions

## 1. Governance Hierarchy & Boundary Matrix

| Agent | Identity & Scope | Read Access | Write Access | Permitted Execution |
| :--- | :--- | :--- | :--- | :--- |
| **Claude Code** | Architect, Graph Validator, Security Reviewer | Entire workspace | `backend/engine/`, `TASK_GRAPH.md`, `STATE_MACHINE.md` | `bun test`, `pytest`, `ruff check`, git review |
| **Antigravity (AGY)** | Headless Builder, UI Developer, Test Implementer | Entire workspace | `frontend/`, `backend/`, `data/processed/`, `tests/` | `bun add`, `bun run dev`, `uv add`, `uvicorn`, browser headless tests |
| **Gemini** | Spec Drafter, Context Memory, Mathematical/Domain Guide | Entire workspace | Spec Markdown (`AGENTS.md`, `TASK_GRAPH.md`) | None (Advisory & Spec authoring) |

## 2. Hard Agent Constraints & Invariants
1. **No Out-of-Graph Execution**: AGY MUST NOT implement any logic or component not explicitly flagged as `READY` in `TASK_GRAPH.md`.
2. **Deterministic Tool Invocation**:
   - Package additions: Always use `bun add` (frontend) and `uv add` (backend). Never invoke `npm`, `yarn`, or raw `pip`.
   - Python code MUST conform to Python 3.12 types, using Pydantic v2 schemas for all I/O.
3. **Loop Circuit Breaker**: If any agent loop fails tests or linting 3 consecutive times on the same subtask, it must flip status to `BLOCKED: CIR_BREAK` and halt execution for architectural review by Claude Code.
""",

    "TASK_GRAPH.md": """# TASK_GRAPH.md: Directed Acyclic Execution Graph (DAG)

Nodes represent discrete task units. A node only transitions from `BLOCKED` to `READY` when all parent dependencies evaluate to `COMPLETED`.

```mermaid
graph TD
    A[G01: Workspace Hardening] --> B[G02: Ingest Schema Engine]
    A --> C[G03: Next.js Frontend Wire]
    B --> D[G04: DuckDB & SQLite Layer]
    B --> E[G05: Watcher Daemon]
    D --> F[G06: Physio & Cardio Periodizer]
    F --> G[G07: Google Calendar & Tasks Sync]
    C --> H[G08: Glassmorphic Biometric HUD]
    G --> I[G09: Integration Canary Test]
    H --> I
